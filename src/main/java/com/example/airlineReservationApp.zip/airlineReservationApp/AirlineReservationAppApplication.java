package com.example.airlineReservationApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirlineReservationAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirlineReservationAppApplication.class, args);
	}

}
