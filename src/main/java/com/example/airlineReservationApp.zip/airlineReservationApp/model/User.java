package com.example.airlineReservationApp.model;

public class User {

}
