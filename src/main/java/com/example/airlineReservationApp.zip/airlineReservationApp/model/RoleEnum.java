package com.example.airlineReservationApp.model;

public enum RoleEnum {
    ADMIN,
    USER
}
